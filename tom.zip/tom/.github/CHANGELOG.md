# Changelog

### V3.3.3

- 'Creepy' Update

- Agradecimentos especiais: [Contribuidores](http://htmlpreview.github.io/?https://github.com/KillovSky/iris/blob/main/.readme/donates/page.html), [Grupo de DEVs](https://chat.whatsapp.com/Ji5JLEVkL0MGRReVvDoubL), [Forks](https://github.com/KillovSky/iris/network/members), [Usuários](https://bit.ly/BOT-IRIS) e a própria [Íris](https://github.com/KillovSky/iris).

---------

1. - Capacidade de rodar/criar comandos com espaços (!teste iris = !testeiris)

2. - Deletar as últimas "X" mensagens de uma pessoa, para casos de ataques.

3. - Limitação no MIX para impedir de farmar rapidamente.

4. - Jogos poderão sem jogados ilimitadamente (sem ganhar/perder nada) se usar -test ou apostar o valor de zero I'coins.

5. - Guildas poderão ser criadas com nomes usando espaços, mas os acentos serao automaticamente removidos.

6. - Converter melhorado, agora impede resultados de se tornarem travas e automaticamente arredonda os valores (depois de 10 sub dígitos para ter um valor muito bem aproximado).

7. - Adicionado sistema de ranking global para competir com outros grupos.

8. - Novo sistema no comando ping.

9. - Steal refeito usando o antigo de base.

10. - Corrigido erro de comandos usando XP como moeda.

11. - Corrigido comando nocmd -show.

12. - Corrigido erro do comando game dando erro ao não achar resultados.

13. - Corrigido problema do play retornar erros em algumas pesquisas.

14. - Criar comandos sem prefix pelo WhatsApp corrigido e limitado a apenas administradores/dono.

15. - Comando de geração de imagens por texto, similar ao dall-e, mas inferior no quesito qualidade e limite, entretanto, sai gratuito... [Limitado!]

16. - Comando dog melhorado, agora é possível obter fotos de mais de 90 raças diferentes (eu ia por sub-racas também mas fica difícil pros usuários usarem) especificando elas no comando.

17. - Comando que adquire um animal aleatório e suas informações como habitat, etc.

18. - Comando que pega foto de patinhos.

19. - Comando que pega foto de gatos melhorado.

20. - Comando que escreve uma mensagem numa foto com gatinhos.

21. - Comando de fatos interessantes sobre cachorros/gatos/outros.

22. - Aumentado dificuldade de subir de nível.

23. - Loteria possui limite de 1 hora de espera agora.

24. - Capacidade de escolher o que deve ser enviado/mostrado na tela/WhatsApp (erros, comandos, tudo, etc)

25. - Comando básico que pega frases de um anime, personagens ou frases aleatórias.

26. - Adicionado 38 comandos de mídias de anime, 41 se contar o comando neko melhorado.

27. - Comando pra pegar fotos de "cat-boys" (por que deus...)

28. - Comando que pega fatos de animes.

29. - Analise de sentimentos (Verifica se a pessoa está Negativa, Positiva ou Neutra).

30. - Comando Greet e Bye foram unificados, foi inserido verificação para confirmar se realmente quer editar (em caso acidental) e capacidade de deletar a mensagem e voltar na padrão da Íris.

31. - Comando Greet e Bye possuem suporte a marcação customizada, caso especificado, basta inserir {userm} na mensagem e ela substituída pela marcação do usuário que entrou/saiu.
		- Não será inserido suporte a imagens ou documentos personalizados, pois este utilizará o espaço da VPS/PC do dono, sendo um risco ao armazenamento em caso de virus e claro, casos de posse ilegal de imagens, caso alguém utilize mídias indevidas no comando.

32. - Comando que remove alertas (warn) recebidos por usuários.

33. - Novo comando duck, pesquisas agora retornam quantos sites acharem, além de um monte de informações junto a elas.

34. - Unificado e refeito os comandos: Randomloli, Yaoi, Masturb, Futanari, Trap, Husb, Baguette, Image, Shota, Yuri.

35. - Alguns comandos adultos agora rodam em grupos sem necessidade do NSFW ativado, retornando imagens comuns sem pornografia, caso ative o NSFW, as imagens serão pornográficas.

36. - Adicionado comando de auto bloquear usuários.

37. - Novo comando clima.

38. - Adicionado suporte dos comandos a imagens, vídeos, GIF's e outros tipos de mídias enviados como documentos.

39. - Admins e Donos podem definir links e textos customizados, caso alguém os envie, a Íris vai banir a pessoa.

40. - Comando que define se a Íris deve marcar as pessoas ou apenas enviar o nickname delas.

41. - Comando que converte valores em números compactos (1000 = 1k, 1000000 = 1m....).

42. - Comandos que usam valores agora podem ser usados com números em sigla, por exemplo, apostar 1k, 1m, 1b, 1t...

43. - Sistema de alias similar ao comando alias do linux, admins, donos e moderadores podem adicionados atalhos para comandos, não precisando mais editar a case, basta adicionar um alias.

44. - Corrigido anti-links, badwords e derivados.

45. - Comandos criados com custom agora tem suporte a marcação, basta inserir {userm} na mensagem.

46. - AFK agora exibe a hora e local em que a pessoa foi vista por último e desativa automaticamente o AFK dela em caso dela enviar uma mensagem.

47. - Sistema de autofotos, similar ao autosticker, so que com fotos, stickergif não é suportado por esse sistema, apenas stickers em imagem.

48. - Sistemas de firewall possuem sistema de "match" para links portado de forma nativa do object padrão das mensagens recebidas pela íris, ou seja, a detecção de links, travas, pornografia e badwords ficou superior ao que estava antes.

49. - As respostas do /iris e /speak serão automaticamente traduzidas para o idioma da iris, entretanto, caso você utilize o sistema cleverbot ou brainshop, você deve falar em inglês, ela responderá no seu idioma, mas você deve falar somente inglês.

50. - Adicionado alguns comandos de imagens de demônios reais, garotas demônios, coisas satânicas do tipo.

51. - Adicionado 'Changelog.md' e 'Code_Of_Conduct.md'.

52. - Site não oficial para edição dos JSON's da Íris por @LeonardoConstantino - [Site](https://leonardoconstantino.github.io/edite-config/).

53. - Adicionado sistema de abrir via arquivo ".bat" para sistemas Windows que possuem erros com o bash, basta clicar no arquivo que ele abrirá o sistema de inicialização da Íris.

54. - Corrigido "core dumped" em computadores com componentes mais antigos.

55. - Adicionado compatibilidade com Heroku [Até novembro ainda vai ter Heroku grátis].

---------

Em breve teremos mais novidades, entre no nosso [grupo](https://bit.ly/BOT-IRIS) para receber todas antes de serem lançadas!

❤️ - Keep Coding - ❤️